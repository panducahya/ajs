# antijs

[![PrankBots](https://img.fireden.net/v/image/1461/72/1461725093324.gif "Prankbots")](https://bit.ly/2xbVxlh) [![tambahkan teman](http://agelessthailand.weebly.com/uploads/7/4/3/5/74358591/9592585_orig.gif "prankbot")](https://bit.ly/2xbVxlh)
- install module
```
apt-get install python3
apt-get install python3-pip
pip3 install requests
pip3 install ffmpy
pip3 install humanfriendly
pip3 install rsa
pip3 install bs4
pip3 install gtts
pip3 install youtube-dl
pip3 install pafy
pip3 install thrift==0.11.0
```
- untuk memperbaiki no module
```
pip3 install (modulenya)
```
- untuk upgrade module
```
pip3 install (modulenya) --upgrade
```

- request folder
```
akad
linepy
thrift
```

- Thanks PrankBots
- Terimakasih untuk selalu menghargai karya indonesia.
